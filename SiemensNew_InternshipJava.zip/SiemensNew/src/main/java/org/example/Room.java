package org.example;

public class Room {
    private int roomNumber;
    private int type;
    private double price;
    private boolean isAvailable;

    private int bookedByUser;

    public int getBookedByUser() {
        return bookedByUser;
    }

    public void setBookedByUser(int bookedByUser) {
        this.bookedByUser = bookedByUser;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}
