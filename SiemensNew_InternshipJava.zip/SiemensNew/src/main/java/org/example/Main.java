package org.example;

import javax.print.attribute.standard.PrinterMakeAndModel;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.random.RandomGenerator;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        HotelReservationSystem reservationSystem = new HotelReservationSystem();


        reservationSystem.loadHotelsFromJson("FileName");
        List<Hotel> hotels = reservationSystem.getHotels();

        System.out.println("Please insert an ID: ");
        int userId = scanner.nextInt();

        User user1 = new User(userId, random.nextDouble(),random.nextDouble());

        System.out.println("Please pick a radius where you want to search the hotels:");
        double radius = scanner.nextDouble();
        reservationSystem.findNearbyHotels(user1.getLatitude(), user1.getLongitude(), radius);


        int answerInt;
        do {
            System.out.println("Please pick:");
            System.out.println("1 - Make a reservation");
            System.out.println("2 - Cancel an existing reservation");
            System.out.println("3 - Leave feedback");

            answerInt = scanner.nextInt();

            if (answerInt != 1 && answerInt != 2 && answerInt != 3) {
                System.out.println("Please pick a correct number:");
            }
        } while (answerInt != 1 && answerInt != 2 && answerInt != 3);

        switch (answerInt){
            case 1: {
                reservationSystem.getAvailableRooms();
                break;
            }
            case 2:
            {
                reservationSystem.cancelReservation();
                break;
            }
            case 3: {
                System.out.println(reservationSystem.leaveFeedBack());
                break;
            }
            default:break;
        }


    }
}