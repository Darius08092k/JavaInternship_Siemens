package org.example;

import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class HotelReservationSystem {
    private List<Hotel> hotels;
    private Scanner scanner;

    public HotelReservationSystem() {
        this.scanner = new Scanner(System.in);
    }

    public void loadHotelsFromJson(String filePath) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            // Read the filepath of the .json file and converts it into the Hotel array
            Hotel[] hotelsArray = objectMapper.readValue(new File(filePath), Hotel[].class);
            hotels = Arrays.asList(hotelsArray);
        } catch (StreamReadException e) {
            throw new RuntimeException(e);
        } catch (DatabindException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Hotel> getHotels() {
        return hotels;
    }

    public List<Hotel> findNearbyHotels(double userLatitude, double userLongitude, double radius) {
        List<Hotel> nearbyHotels = new ArrayList<>();

        for (Hotel hotel : hotels) {
            double distance = calculateDistance(userLatitude, userLongitude, hotel.getLatitude(), hotel.getLongitude());
            if (distance <= radius) {
                nearbyHotels.add(hotel);
            }
        }

        for (Hotel nearbyFoundHotels : nearbyHotels) {
            System.out.println("Hotel: " + nearbyFoundHotels.getName() + " found nearby.");
        }
        return nearbyHotels;
    }

    public double convertUserPosToMeters(double latUser, double longtUser) {
        double latMeters = latUser * 111.139;
        double lonMeters = longtUser * (111.139 * Math.cos(Math.toRadians(latUser)));
        return Math.sqrt(latMeters * latMeters + lonMeters * lonMeters);
    }

    public double convertHotelPosToMeters(double latHotel, double longHotel) {
        double latMeters = latHotel * 111.139;
        double lonMeters = longHotel * (111.139 * Math.cos(Math.toRadians(latHotel)));
        return Math.sqrt(latMeters * latMeters + lonMeters * lonMeters);
    }

    public double calculateDistance(double latUser, double longtUser, double latHotel, double longHotel) {
        double userPositionMeters = convertUserPosToMeters(latUser, longtUser);

        // Convert hotel's position to meters
        double hotelPositionMeters = convertHotelPosToMeters(latHotel, longHotel);

        // Calculate the absolute difference between the two positions
        return Math.abs(userPositionMeters - hotelPositionMeters);
    }

    public void getAvailableRooms() {
        for (Hotel hotel : hotels) {
            System.out.println("Available rooms in " + hotel.getName() + ":");
            for (Room room : hotel.getRooms()) {
                if (room.isAvailable()) {
                    System.out.println("Room number: " + room.getRoomNumber());
                    System.out.println("Room price: " + room.getPrice());
                }
            }
            System.out.println("Enter the room number you want to book: ");
            int roomId = scanner.nextInt();
            System.out.println("Enter your user ID: ");
            int userId = scanner.nextInt();
            for (Room room : hotel.getRooms()) {
                if (room.getRoomNumber() == roomId) {
                    System.out.println("Room ID: " + room.getRoomNumber() + " reserved");
                    room.setAvailable(false);
                    room.setBookedByUser(userId);
                }
            }
            break;
        }
    }



    public void cancelReservation() {
        // Search for the reservation with the given ID
        System.out.println("Enter your user ID: ");
        int userId = scanner.nextInt();
        for (Hotel hotel : hotels) {
            for (Room room : hotel.getRooms()) {
                if (room.getBookedByUser() == userId) {
                    System.out.println("Reservation found under the user: " + userId);
                    String answer;
                    do {
                        System.out.println("Do you want to cancel the reservation? (Y/N)");
                        answer = scanner.next();
                        if (!answer.toUpperCase().startsWith("Y") && !answer.toUpperCase().startsWith("N")) {
                            System.out.println("Please pick Y/N");
                        }
                    } while (!answer.toUpperCase().startsWith("Y") && !answer.toUpperCase().startsWith("N"));
                    if (answer.toUpperCase().startsWith("Y")) {
                        System.out.println("Reservation cancelled!");
                        room.setAvailable(true);
                        room.setBookedByUser(-1);
                    }
                }
            }
            break;
        }
    }

    public String leaveFeedBack() {
        // Search for the reservation with the given ID
        System.out.println("Enter your user ID: ");
        int userId = scanner.nextInt();
        String feedbackAnswer = null;
        for (Hotel hotel : hotels) {
            for (Room room : hotel.getRooms()) {
                if (room.getBookedByUser() == userId) {
                    System.out.println("Please type your feedback: ");
                    feedbackAnswer = scanner.next();
                }
            }
            break;
        }
        return feedbackAnswer;
    }
}
