package org.example;

public class User {
    private int userID;
    private double latitude;
    private double longitude;

    public User(int userID, double latitude, double longitude) {
        this.userID = userID;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
